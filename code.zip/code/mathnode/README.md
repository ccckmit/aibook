﻿MathNode is a Mathematics Platform in JavaScript
==================================================

Author
-----------------
Chung-Chen Chen (陳鍾誠)

Project Host
--------------
https://github.com/ccckmit/mathnode


Related Project
-------------------
1. node.js -- The testing platform
2. jStat -- jStat.js (modify by ccc to jStat_ccc.js)
3. numericjs -- numeric.js


