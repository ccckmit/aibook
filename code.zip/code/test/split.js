var code = "A<=B. B<=C&D. . C<=E. D<=F. E. F. Z<=C&D&G. ";
// var code = "";
var lines = code.split(/\.+ ?/);
console.log("lines=%j", lines);