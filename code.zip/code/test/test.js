var log = console.log;

var s = "Hello World !";

log("s[3]=%s", s[3]);
s[3] = 'x';
log("s[3]=%s", s[3]);
